export interface TaskHistoryModel{
    id: string;
    taskId: string;
    status: string;
    created_at: string;
    updated_at: string;
}